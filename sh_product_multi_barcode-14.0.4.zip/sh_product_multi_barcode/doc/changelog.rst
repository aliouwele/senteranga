Changelog
=========
14.0.1
-------------------------
Initial Release

14.0.2 (20th Oct 2020)
-------------------------
change in _name_search method.

14.0.3 (10 dec 2020)
-------------------------
Add configuration to check duplication of barcode in product and put constraint in multi barcodes and put multi barcode field in search view also.

14.0.4 (Date: 30th Dec 2020)
===============================
[FIX]if removed a barcode line from a product or delete a product of multi barcode then delete that barcode record also from multi barcode.  